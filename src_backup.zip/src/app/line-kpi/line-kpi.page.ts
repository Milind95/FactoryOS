import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-line-kpi',
  templateUrl: './line-kpi.page.html',
  styleUrls: ['./line-kpi.page.scss'],
})
export class LineKPIPage implements OnInit {
  customActionSheetOptions: any = {
    header: 'Shift',
    subHeader: 'Select Shift'
  };
  subStages = [{
    'subStageId': 1,
    'subStageName': 'Chassie Fitter',
    'subStageEfficiency': 85,
    'machineList': [{
      'machineId': 12,
      'machineName': 'Machine 1',
      'machineStatus': 'Completed',
      'machineEfficiency': '90%'
    },
    {
      'machineId': 14,
      'machineName': 'Machine 2',
      'machineStatus': 'In-Progress',
      'machineEfficiency': '80%'
    }]
  },
  {
    'subStageId': 2,
    'subStageName': 'Window Fitter',
    'subStageEfficiency': 45,
    'machineList': [{
      'machineId': 16,
      'machineName': 'Machine 3',
      'machineStatus': 'bottleNeck',
      'machineEfficiency': '25%'
    },
    {
      'machineId': 17,
      'machineName': 'Machine 4',
      'machineStatus': 'Not-Started',
      'machineEfficiency': '78%'
    }]
  },
  {
    'subStageId': 3,
    'subStageName': 'Car Painter',
    'subStageEfficiency': 87,
    'machineList': [{
      'machineId': 19,
      'machineName': 'Machine 5',
      'machineStatus': 'Not-Started',
      'machineEfficiency': '89%'
    },
    {
      'machineId': 14,
      'machineName': 'Machine 6',
      'machineStatus': 'Not-Started',
      'machineEfficiency': '86%'
    }]
  }];
  constructor() { }

  ngOnInit() {
  }

  doRefresh(event) {
    console.log(event);
    setTimeout(() => {
      console.log('Async operation has ended');
      event.target.complete();
    }, 2000);
  }
}
